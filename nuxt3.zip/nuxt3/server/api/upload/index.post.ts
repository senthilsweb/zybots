import type {IncomingMessage, ServerResponse} from "http";
import formidable, {errors as formidableErrors} from "formidable";
const form = formidable({multiples: true});
export default async (req: IncomingMessage, res: ServerResponse) => {
	console.log(req);

	//console.log(body.toString());
	//const fileBuffer = Buffer.from(body, "utf-8");
	/*const recordset = await $fetch(`${process.env.CLOUDINMARY_API_ENDPOINT}/${process.env.CLOUDINMARY_CLOUD_NAME}/image/upload`, {
		method: "post",
		headers: {
			"Content-Type": "multipart/form-data",
			//"api-key": `${process.env.MONGODB_ATLAS_REST_TOKEN}`,
		},
		body: body,
	});
	return recordset;*/
};
//6315d02dd586196150c8950c
/*
CLOUDINMARY_API_ENDPOINT=https://api.cloudinary.com/v1_1/
CLOUDINMARY_CLOUD_NAME=nathansweb
CLOUDINMARY_UPLOAD_PRESET=templr-assets
CLOUDINMARY_API_KEY=267219765594665
CLOUDINMARY_API_SECRET=qTNrtopNI6kMhcVSx-FFv6GgY2c
*/
