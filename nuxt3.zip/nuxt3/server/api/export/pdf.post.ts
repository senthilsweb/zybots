import { Readable } from 'stream';
import { sendStream } from 'h3'
import puppeteer from 'puppeteer'
export default defineEventHandler(async (event) => {
	//Get request payload
	const body = await readBody(event); // only for POST | PUT | PATCH | DELETE requests
	const url = body.url;
	const output_file_name = body.output_file_name
	
	//Business logic to generate word file from the template and data passed.
	try {
		const browser = await puppeteer.launch({ headless: true });
		const page = await browser.newPage();
		await page.goto(url, {waitUntil: 'networkidle0'});
		const pdf = await page.pdf({ format: 'A4' });
  		await browser.close();

		var stream = new Readable();
		stream.push(pdf);
		stream.push(null);
		event.res.setHeader('Content-Disposition', 'attachment; filename=' + output_file_name);
		return sendStream(event, stream)
		
	} catch (e) {
		event.res.statusCode = 500;
		return {
			status: "Failure",
			exception: e,
			message: `Failure during pdf export [${e.message}]`,
		};
	}

});
