export default defineEventHandler((event) => {
  return { uptime: process.uptime(),
    responsetime: process.hrtime(),
    message: `OK`,
    timestamp: Date.now(), }
})