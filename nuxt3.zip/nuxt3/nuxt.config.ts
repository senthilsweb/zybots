import {defineNuxtConfig} from "nuxt/config";

// https://v3.nuxtjs.org/docs/directory-structure/nuxt.config

export default defineNuxtConfig({
	nitro: {},
	tailwindcss: {
		cssPath: "~/assets/css/tailwind.css",
		configPath: "tailwind.config",
		exposeConfig: false,
		injectPosition: 0,
		viewer: true,
	},
	/*
	 ** Plugins to load before mounting the App
	 */

	router: {},

	build: {
		transpile: [],
		
	},
	buildModules: [
		
	],
	alias: {
		pinia: "/node_modules/@pinia/nuxt/node_modules/pinia/dist/pinia.mjs",
	},
	runtimeConfig: {
		// Private config that is only available on the server
		MONGODB_ATLAS_REST_URL: process.env.MONGODB_ATLAS_REST_URL,
		MONGODB_ATLAS_REST_TOKEN: process.env.MONGODB_ATLAS_REST_TOKEN,
		GOOGLE_MAP_TOKEN: process.env.GOOGLE_MAP_TOKEN,
		// Config within public will be also exposed to the client
		public: {
			BASE_URL: process.env.MONGODB_ATLAS_REST_URL,
		},
	},
	modules: [],

	content: {
		// https://content.nuxtjs.org/api/configuration
	},
});
