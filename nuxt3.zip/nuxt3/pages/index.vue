<template>
  <div class="flex flex-col justify-center w-full h-screen max-w-3xl mx-auto space-y-2">
    <div>
      <h1 class="text-2xl">About</h1>
      <p class="text-lg">I'm learning about Nuxt 3! Here's what I've achieved so far:</p>
    </div>
    <ul class="mx-8 list-disc">
      <li>
        Created a new Nuxt 3 project
      </li>
      <li>
        Added Tailwind
      </li>
      <li>
        Created a new page
      </li>
    </ul>
  </div>  
</template>